import '../Pages/Hotel.css'
export default function Facilites({list, id, type}){

    return(
        <div>
            <h3>{type}</h3>
                <div className="f_list">
                    {list.map((item, index)=>(
                        item.facilitytype_id===id?
                    <li key={index}>
                        {item.facility_name}
                    </li>:
                    null
                ))}
                </div>
        </div>
    ) 
}
// {facilities.map((item, index)=>(
//     item.facilitytype_id===3?
// <li key={index}>
//     {item.facility_name}
// </li>:
// null
// ))}
// </div>
// <h3>Ski</h3>
// <div className="f_list">

// {facilities.map((item, index)=>(
//     item.facilitytype_id===10?
// <li key={index}>
//     {item.facility_name}
// </li>:
// null
// ))}
// </div>
// <h3>Miscellaneous</h3>
// <div className="f_list">

// {facilities.map((item, index)=>(
//     item.facilitytype_id===29?
// <li key={index}>
//     {item.facility_name}
// </li>:
// null
// ))}

// h3>General</h3>
//                 <div className="f_list">
                    
//                     {facilities.map((item, index)=>(
//                         item.facilitytype_id===1?
//                     <li key={index}>
//                         {item.facility_name}
//                     </li>:
//                     null
//                 ))}
//                 </div>
//                 <h3>Activities</h3>
//                 <div className="f_list">
                    
//                     {facilities.map((item, index)=>(
//                         item.facilitytype_id===2?
//                     <li key={index}>
//                         {item.facility_name}
//                     </li>:
//                     null
//                 ))}
//                 </div>
//                 <h3>Services</h3>
//                 <div className="f_list">
//                      </div>
//                 <h3>Reception Services</h3>
//                 <div className="f_list">
                    
//                     {facilities.map((item, index)=>(
//                         item.facilitytype_id===23?
//                     <li key={index}>
//                         {item.facility_name}
//                     </li>:
//                     null
//                 ))}
//                 </div>
